import React, { useState } from 'react';
import { Sparkles, Brain, AlertTriangle, CheckCircle, TrendingDown, HelpCircle } from 'lucide-react';
import { AIPrediction, MultiplierRecord } from '../types';

interface AIAdvisorProps {
  multiplierHistory: MultiplierRecord[];
  onPredict: () => Promise<void>;
  prediction: AIPrediction | null;
  loading: boolean;
  error: string | null;
}

export default function AIAdvisor({ multiplierHistory, onPredict, prediction, loading, error }: AIAdvisorProps) {
  const getRiskColor = (level: string) => {
    switch (level) {
      case 'LOW': return 'bg-emerald-950/60 text-emerald-400 border-emerald-900';
      case 'MEDIUM': return 'bg-amber-950/60 text-amber-400 border-amber-900';
      case 'HIGH': return 'bg-orange-950/60 text-orange-400 border-orange-900';
      case 'CRITICAL': return 'bg-rose-950/60 text-rose-400 border-rose-900 animate-pulse';
      default: return 'bg-neutral-800 text-neutral-400 border-neutral-700';
    }
  };

  return (
    <div id="ai-advisor-panel" className="glass-card rounded-2xl p-6 shadow-2xl relative overflow-hidden">
      {/* Background glow decorator */}
      <div className="absolute -top-12 -right-12 w-32 h-32 bg-rose-500/5 rounded-full blur-3xl pointer-events-none"></div>

      <div className="flex justify-between items-center mb-4 border-b border-white/5 pb-3">
        <h3 className="text-sm font-display font-bold text-white flex items-center gap-2 uppercase tracking-widest">
          <Brain className="text-rose-500" size={18} />
          Gemini AI Advisor
        </h3>
        <button
          id="btn-trigger-ai-analysis"
          onClick={onPredict}
          disabled={loading || multiplierHistory.length < 5}
          className={`flex items-center gap-2 py-1.5 px-3.5 rounded-xl text-xs font-display font-semibold transition-all cursor-pointer ${
            multiplierHistory.length < 5
              ? 'bg-white/5 text-slate-600 cursor-not-allowed border border-white/5'
              : 'bg-gradient-to-r from-rose-600 to-pink-500 hover:from-rose-500 hover:to-pink-400 text-white shadow-lg shadow-rose-950/40 hover:shadow-rose-500/20'
          }`}
        >
          <Sparkles size={13} className={loading ? 'animate-spin' : ''} />
          {loading ? 'Analyzing...' : 'Run Advisor'}
        </button>
      </div>

      {multiplierHistory.length < 5 ? (
        <div className="bg-[#080b16]/50 rounded-xl p-6 border border-white/5 text-center">
          <TrendingDown className="text-slate-600 mx-auto mb-2" size={24} />
          <p className="text-xs font-semibold text-slate-300">Insufficient Data Points</p>
          <p className="text-[11px] text-slate-500 mt-1">Please record at least 5 multipliers before running Gemini Advisor.</p>
        </div>
      ) : error ? (
        <div className="bg-rose-950/10 border border-rose-900/30 rounded-xl p-4 text-xs text-rose-400">
          <p className="font-semibold flex items-center gap-1.5 mb-1">
            <AlertTriangle size={14} />
            Advisor Encountered an Error
          </p>
          <p className="text-slate-400">{error}</p>
          <p className="text-[10px] text-slate-500 mt-2 font-mono">Ensure GEMINI_API_KEY is configured in your secrets.</p>
        </div>
      ) : loading ? (
        <div className="bg-[#080b16]/50 rounded-xl p-8 border border-white/5 flex flex-col items-center justify-center space-y-3">
          <div className="w-8 h-8 border-2 border-rose-500 border-t-transparent rounded-full animate-spin"></div>
          <p className="text-xs font-mono text-rose-400 animate-pulse">Analyzing sequence data...</p>
          <p className="text-[10px] text-slate-500">Gemini-2.5-Flash feeding historical series into statistical matrix...</p>
        </div>
      ) : prediction ? (
        <div className="space-y-4">
          {/* Summary Block */}
          <div className="bg-[#080b16]/60 p-4 rounded-xl border border-white/5 text-xs">
            <p className="font-semibold text-rose-400 mb-1.5 flex items-center gap-1 font-display uppercase tracking-wider text-[10px]">
              <CheckCircle size={13} className="text-rose-400" />
              Statistical Series Synthesis
            </p>
            <p className="text-slate-300 leading-relaxed font-sans">{prediction.summary}</p>
          </div>

          {/* Patterns Detected */}
          <div>
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest block mb-2 font-display">
              Detected Anomalies & Patterns
            </span>
            <div className="space-y-1.5">
              {prediction.detectedPatterns.map((p, i) => (
                <div key={i} className="text-xs bg-[#080b16]/40 py-2 px-3 rounded-xl border border-white/5 flex items-center gap-2 text-slate-300">
                  <span className="w-1.5 h-1.5 rounded-full bg-rose-500 shrink-0"></span>
                  {p}
                </div>
              ))}
              {prediction.detectedPatterns.length === 0 && (
                <p className="text-xs text-slate-500 italic">No strong anomalies detected in this segment.</p>
              )}
            </div>
          </div>

          {/* Next Round Forecast */}
          <div className="bg-[#080b16]/60 p-4 rounded-xl border border-white/5 space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest font-display">
                Next Round Forecast
              </span>
              <span className={`text-[10px] font-bold px-2.5 py-0.5 border rounded-full uppercase ${getRiskColor(prediction.nextRoundForecast.riskLevel)}`}>
                {prediction.nextRoundForecast.riskLevel} Risk
              </span>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <span className="text-[10px] text-slate-500 block mb-0.5">Predicted Target Range</span>
                <span className="text-sm font-mono font-bold text-slate-200">
                  {prediction.nextRoundForecast.range}
                </span>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-slate-500 block mb-0.5">Probability &lt; 20.0x</span>
                <span className="text-sm font-mono font-bold text-rose-400">
                  {prediction.nextRoundForecast.probabilityUnder20}%
                </span>
              </div>
            </div>

            {/* Probability Slider Bar */}
            <div className="space-y-1">
              <div className="h-1.5 bg-[#05070e] rounded-full overflow-hidden flex">
                <div 
                  className="bg-rose-500 h-full" 
                  style={{ width: `${prediction.nextRoundForecast.probabilityUnder20}%` }}
                ></div>
                <div 
                  className="bg-indigo-500 h-full" 
                  style={{ width: `${prediction.nextRoundForecast.probabilityOver20}%` }}
                ></div>
              </div>
              <div className="flex justify-between text-[9px] text-slate-600 font-mono">
                <span>Under 20x ({prediction.nextRoundForecast.probabilityUnder20}%)</span>
                <span>Over 20x ({prediction.nextRoundForecast.probabilityOver20}%)</span>
              </div>
            </div>
          </div>

          {/* Strategy Advice */}
          <div className="bg-rose-950/10 border border-rose-900/20 p-4 rounded-xl space-y-1.5">
            <span className="text-[10px] font-bold text-rose-400 uppercase tracking-widest block font-display">
              Risk Management Advice
            </span>
            <p className="text-xs text-slate-300 leading-relaxed font-sans">
              {prediction.strategyAdvice}
            </p>
          </div>

          <div className="text-[10px] text-slate-600 text-center flex items-center justify-center gap-1 font-mono">
            <HelpCircle size={12} className="opacity-70" />
            Predictions are statistical. Crash outcomes are independent. Use with caution.
          </div>
        </div>
      ) : (
        <div className="bg-[#080b16]/50 rounded-xl p-6 border border-white/5 text-center">
          <Brain className="text-slate-600 mx-auto mb-2" size={24} />
          <p className="text-xs text-slate-400 font-medium">No Analysis Loaded</p>
          <p className="text-[10px] text-slate-500 mt-1">Click "Run Advisor" to let Gemini search the database history and map out upcoming probability ratios.</p>
        </div>
      )}
    </div>
  );
}
