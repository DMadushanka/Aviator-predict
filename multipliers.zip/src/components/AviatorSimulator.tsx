import React, { useState, useEffect, useRef } from 'react';
import { Play, Square, RefreshCw, Volume2, VolumeX, ShieldAlert } from 'lucide-react';

interface AviatorSimulatorProps {
  onMultiplierAdded: (multiplier: number) => void;
  autoSave: boolean;
  setAutoSave: (value: boolean) => void;
}

export default function AviatorSimulator({ onMultiplierAdded, autoSave, setAutoSave }: AviatorSimulatorProps) {
  const [gameState, setGameState] = useState<'idle' | 'running' | 'crashed'>('idle');
  const [multiplier, setMultiplier] = useState<number>(1.00);
  const [crashPoint, setCrashPoint] = useState<number>(1.00);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [autoLoop, setAutoLoop] = useState<boolean>(false);

  const timerRef = useRef<any>(null);
  const startTimeRef = useRef<number>(0);
  const audioCtxRef = useRef<AudioContext | null>(null);

  // Initialize Web Audio context on first user interaction
  const initAudio = () => {
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
  };

  // Sound generator
  const playTone = (freq: number, type: OscillatorType, duration: number, volume: number = 0.1) => {
    if (!soundEnabled || !audioCtxRef.current) return;
    try {
      initAudio();
      if (audioCtxRef.current.state === 'suspended') {
        audioCtxRef.current.resume();
      }
      const osc = audioCtxRef.current.createOscillator();
      const gain = audioCtxRef.current.createGain();
      
      osc.type = type;
      osc.frequency.setValueAtTime(freq, audioCtxRef.current.currentTime);
      
      gain.gain.setValueAtTime(volume, audioCtxRef.current.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, audioCtxRef.current.currentTime + duration);
      
      osc.connect(gain);
      gain.connect(audioCtxRef.current.destination);
      
      osc.start();
      osc.stop(audioCtxRef.current.currentTime + duration);
    } catch (e) {
      console.warn("Audio playing failed", e);
    }
  };

  // Simulate Aviator's official RNG distribution
  // 3% instant crash at 1.00x, otherwise Pareto distributed formula: 0.97 / (1 - U)
  const generateCrashPoint = (): number => {
    const isInstantCrash = Math.random() < 0.03;
    if (isInstantCrash) {
      return 1.00;
    }
    
    const u = Math.random(); // [0, 1)
    // House edge calculation
    const rawVal = 0.97 / (1 - u);
    
    // Minimum crash point is always 1.01x in normal operation
    const crash = Math.max(1.01, Math.round(rawVal * 100) / 100);
    
    // Cap at a reasonable massive multiplier (e.g. 5000x)
    return Math.min(5000, crash);
  };

  const handleStart = () => {
    initAudio();
    playTone(300, 'sawtooth', 0.2, 0.15);
    setTimeout(() => playTone(450, 'sawtooth', 0.2, 0.15), 100);

    const targetCrash = generateCrashPoint();
    setCrashPoint(targetCrash);
    setMultiplier(1.00);
    setGameState('running');
    startTimeRef.current = Date.now();

    if (timerRef.current) clearInterval(timerRef.current);

    timerRef.current = setInterval(() => {
      const elapsed = (Date.now() - startTimeRef.current) / 1000;
      
      // Multiplier formula: exponential rise, starting at 1.00
      // M = 1.00 * e^(0.07 * t^1.15)
      const currentMult = 1.00 * Math.exp(0.08 * Math.pow(elapsed, 1.1));
      const roundedMult = Math.round(currentMult * 100) / 100;

      if (roundedMult >= targetCrash) {
        // Plane crashes / flies away!
        clearInterval(timerRef.current);
        setMultiplier(targetCrash);
        setGameState('crashed');
        playTone(120, 'sawtooth', 0.6, 0.25); // crash explosion tone
        
        onMultiplierAdded(targetCrash);
      } else {
        setMultiplier(roundedMult);
        // Play ticking beep sound that pitches up slowly
        if (Math.floor(elapsed * 10) % 4 === 0) {
          playTone(200 + roundedMult * 5, 'sine', 0.05, 0.05);
        }
      }
    }, 40);
  };

  const handleStop = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }
    setGameState('idle');
  };

  // Auto-simulation loop effect
  useEffect(() => {
    let timeout: any = null;
    if (autoLoop && gameState === 'crashed') {
      timeout = setTimeout(() => {
        handleStart();
      }, 3000); // Wait 3 seconds before next flight
    }
    return () => clearTimeout(timeout);
  }, [autoLoop, gameState]);

  // Cleanup timers
  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  return (
    <div id="aviator-simulator-panel" className="glass-card rounded-2xl overflow-hidden p-6 shadow-2xl relative">
      {/* Absolute Header badge */}
      <div className="absolute top-4 right-4 flex items-center gap-3">
        <button
          id="btn-toggle-sound"
          onClick={() => { initAudio(); setSoundEnabled(!soundEnabled); }}
          className={`p-2 rounded-xl transition-all cursor-pointer ${
            soundEnabled ? 'bg-rose-500/10 text-rose-400 hover:bg-rose-500/20 hover:scale-105' : 'bg-white/5 text-slate-500 hover:bg-white/10'
          }`}
          title={soundEnabled ? "Mute sounds" : "Enable sounds"}
        >
          {soundEnabled ? <Volume2 size={16} /> : <VolumeX size={16} />}
        </button>
      </div>

      <h3 className="text-sm font-display font-bold text-white flex items-center gap-2 mb-4 uppercase tracking-widest border-b border-white/5 pb-3">
        <span className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-pulse shadow-md shadow-rose-500/80"></span>
        Flight Simulation Deck
      </h3>

      {/* Interactive Visual Flight Stage */}
      <div className="h-56 bg-[#030611] rounded-2xl border border-white/5 relative overflow-hidden flex flex-col justify-between p-4 shadow-inner shadow-black/80">
        {/* Grids and backgrounds */}
        <div className="absolute inset-0 grid grid-cols-6 grid-rows-4 opacity-[0.03] pointer-events-none">
          {Array.from({ length: 24 }).map((_, i) => (
            <div key={i} className="border-t border-l border-white"></div>
          ))}
        </div>

        {/* Current State Label */}
        <div className="flex justify-between items-center z-10">
          <span className="text-[10px] font-mono text-slate-500 bg-[#080d1a] px-2.5 py-1 rounded-full border border-white/5">
            RNG SEED: ACTIVE
          </span>
          {gameState === 'running' && (
            <span className="text-[10px] font-mono text-rose-400 bg-rose-950/20 border border-rose-900/40 px-2.5 py-1 rounded-full animate-pulse tracking-wide font-semibold">
              IN FLIGHT
            </span>
          )}
          {gameState === 'crashed' && (
            <span className="text-[10px] font-mono text-slate-400 bg-white/5 border border-white/5 px-2.5 py-1 rounded-full">
              COOLDOWN
            </span>
          )}
        </div>

        {/* Dynamic Display Center */}
        <div className="flex flex-col items-center justify-center flex-grow z-10 select-none">
          {gameState === 'idle' && (
            <div className="text-center">
              <p className="text-xs text-slate-400 font-display uppercase tracking-widest">Ready for Takeoff</p>
              <p className="text-[10px] text-slate-600 mt-1.5 font-mono">Simulates Spribe Aviator true mathematical probability curves</p>
            </div>
          )}

          {gameState === 'running' && (
            <div className="text-center">
              <span className="text-5xl md:text-6xl font-mono font-bold tracking-tighter text-white neon-red-text">
                {multiplier.toFixed(2)}x
              </span>
            </div>
          )}

          {gameState === 'crashed' && (
            <div className="text-center">
              <p className="text-[10px] text-rose-500 uppercase tracking-widest font-display font-bold mb-1">
                Flew Away
              </p>
              <span className="text-4xl md:text-5xl font-mono font-bold tracking-tighter text-slate-500">
                {multiplier.toFixed(2)}x
              </span>
            </div>
          )}
        </div>

        {/* Flight Path SVG Overlay */}
        {gameState === 'running' && (
          <svg className="absolute inset-0 w-full h-full pointer-events-none z-0">
            {/* Draw curve trail */}
            <path
              d={`M 0,224 Q ${Math.min(300, multiplier * 40)},${Math.max(40, 224 - multiplier * 15)} ${Math.min(100 + multiplier * 35, 500)},${Math.max(20, 224 - multiplier * 15)}`}
              fill="none"
              stroke="url(#trail-gradient)"
              strokeWidth="4"
              strokeLinecap="round"
              className="transition-all duration-75"
            />
            {/* Gradient definition */}
            <defs>
              <linearGradient id="trail-gradient" x1="0%" y1="100%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#881337" stopOpacity="0.1" />
                <stop offset="50%" stopColor="#f43f5e" stopOpacity="0.4" />
                <stop offset="100%" stopColor="#fda4af" stopOpacity="0.9" />
              </linearGradient>
            </defs>

            {/* Glowing neon plane icon */}
            <g
              transform={`translate(${Math.min(100 + multiplier * 35, 500) - 15}, ${Math.max(20, 224 - multiplier * 15) - 15})`}
              className="plane-flight"
            >
              <circle cx="15" cy="15" r="14" fill="#fda4af" fillOpacity="0.15" />
              <path
                d="M15,5 L17,11 L24,11 L19,15 L21,21 L15,17 L9,21 L11,15 L6,11 L13,11 Z"
                fill="#f43f5e"
                stroke="#ffe4e6"
                strokeWidth="1.5"
              />
            </g>
          </svg>
        )}

        {/* X-Y Axis labels */}
        <div className="flex justify-between items-center text-[9px] font-mono text-slate-600 z-10 border-t border-white/5 pt-1.5">
          <span>0.0s</span>
          <span className="uppercase tracking-wider">Tactical Altitude Matrix</span>
        </div>
      </div>

      {/* Simulation Controls */}
      <div className="grid grid-cols-2 gap-4 mt-5">
        {gameState === 'running' ? (
          <button
            id="btn-sim-stop"
            onClick={handleStop}
            className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-white/5 text-slate-300 hover:bg-white/10 font-display font-semibold transition-all border border-white/5 hover:border-white/10 cursor-pointer"
          >
            <Square size={16} />
            Abort Flight
          </button>
        ) : (
          <button
            id="btn-sim-start"
            onClick={handleStart}
            className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-rose-600 to-rose-500 hover:from-rose-500 hover:to-rose-400 text-white font-display font-semibold transition-all shadow-lg shadow-rose-950/40 hover:shadow-rose-500/20 cursor-pointer"
          >
            <Play size={16} />
            Launch Flight
          </button>
        )}

        <div className="flex flex-col justify-center pl-2">
          <label className="flex items-center gap-2.5 text-xs text-slate-400 cursor-pointer select-none">
            <input
              id="chk-auto-loop"
              type="checkbox"
              checked={autoLoop}
              onChange={(e) => setAutoLoop(e.target.checked)}
              className="rounded bg-[#080b16] border-white/10 text-rose-500 focus:ring-0 w-4 h-4 cursor-pointer"
            />
            Autopilot Loop
          </label>
          <label className="flex items-center gap-2.5 text-xs text-slate-400 cursor-pointer select-none mt-2.5">
            <input
              id="chk-auto-save"
              type="checkbox"
              checked={autoSave}
              onChange={(e) => setAutoSave(e.target.checked)}
              className="rounded bg-[#080b16] border-white/10 text-rose-500 focus:ring-0 w-4 h-4 cursor-pointer"
            />
            Database Auto-Sync
          </label>
        </div>
      </div>

      {/* Probability Math Explanation Badge */}
      <div className="mt-4 bg-[#080b16]/40 p-3.5 rounded-xl border border-white/5 flex gap-3">
        <ShieldAlert size={16} className="text-slate-500 shrink-0 mt-0.5" />
        <div className="text-[11px] leading-relaxed text-slate-500 font-mono">
          <strong className="text-slate-400">Mathematical RNG:</strong> 3% instant-crash at 1.00x. The remaining 97% obey $X = 0.97 / (1-U)$ representing true Spribe Aviator risk equations. Use to safely backtest strategy sequences.
        </div>
      </div>
    </div>
  );
}
