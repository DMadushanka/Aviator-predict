import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  app.use(express.json());
  app.use(express.text({ type: "text/plain" }));

  // Custom CORS middleware to accept multiplier records from external browser sessions
  app.use((req, res, next) => {
    const origin = req.headers.origin;
    if (origin) {
      res.header("Access-Control-Allow-Origin", origin);
      res.header("Vary", "Origin");
    } else {
      res.header("Access-Control-Allow-Origin", "*");
    }
    res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, Authorization, Bypass-Tunnel-Reminder, ngrok-skip-browser-warning");
    res.header("Access-Control-Allow-Methods", "GET, POST, OPTIONS, PUT, DELETE");
    res.header("Access-Control-Allow-Private-Network", "true");
    if (req.method === "OPTIONS") {
      return res.sendStatus(200);
    }
    next();
  });

  const PORT = 3000;

  console.log("Running in local file-based storage mode");

  // File-based persistent storage for local mode
  const MULTIPLIERS_FILE = path.join(process.cwd(), "multipliers.json");

  function getLocalMultipliers(): any[] {
    try {
      if (fs.existsSync(MULTIPLIERS_FILE)) {
        const fileContent = fs.readFileSync(MULTIPLIERS_FILE, "utf-8");
        return JSON.parse(fileContent);
      }
    } catch (err) {
      console.error("Error reading multipliers.json:", err);
    }
    return [];
  }

  function saveLocalMultipliers(data: any[]) {
    try {
      fs.writeFileSync(MULTIPLIERS_FILE, JSON.stringify(data, null, 2), "utf-8");
    } catch (err) {
      console.error("Error writing multipliers.json:", err);
    }
  }

  // Initialize file-based fallback
  let localMultipliers = getLocalMultipliers();

  // API: Get history of multipliers
  app.get("/api/multipliers", async (req, res) => {
    try {
      // Read fresh copy from file to prevent out-of-sync states
      localMultipliers = getLocalMultipliers();
      res.json([...localMultipliers].reverse());
    } catch (error: any) {
      console.error("Error fetching multipliers:", error);
      res.status(500).json({ error: error.message || "Failed to fetch multipliers" });
    }
  });

  // API: Save a new multiplier
  app.post("/api/multipliers", async (req, res) => {
    try {
      let data = req.body;
      if (typeof data === "string") {
        try {
          data = JSON.parse(data);
        } catch (e) {
          return res.status(400).json({ error: "Invalid JSON in text/plain body" });
        }
      }
      
      const { multiplier, source } = data || {};
      if (typeof multiplier !== "number" || isNaN(multiplier) || multiplier < 1.0) {
        return res.status(400).json({ error: "Invalid multiplier value. Must be >= 1.0" });
      }

      const record = {
        multiplier: Math.round(multiplier * 100) / 100, // round to 2 decimals
        timestamp: Date.now(),
        source: source || "manual"
      };

      const id = "local_" + Math.random().toString(36).substring(2, 11);
      const localRecord = { id, ...record };
      
      localMultipliers = getLocalMultipliers();
      localMultipliers.push(localRecord);
      // Keep local history capped to 1000 items
      if (localMultipliers.length > 1000) {
        localMultipliers.shift();
      }
      saveLocalMultipliers(localMultipliers);
      res.json(localRecord);
    } catch (error: any) {
      console.error("Error adding multiplier:", error);
      res.status(500).json({ error: error.message || "Failed to save multiplier" });
    }
  });

  // API: Analyze patterns and predict next range using Gemini AI
  app.post("/api/predict", async (req, res) => {
    try {
      const { multipliers } = req.body;
      if (!Array.isArray(multipliers) || multipliers.length === 0) {
        return res.status(400).json({ error: "Invalid multipliers history provided" });
      }

      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
        return res.status(400).json({ error: "Gemini API Key is not configured. Please configure it in your Secrets panel in AI Studio." });
      }

      const ai = new GoogleGenAI({ apiKey });
      
      const multiplierList = multipliers.slice(0, 50).map(m => m.multiplier).reverse(); // oldest to newest
      
      const prompt = `You are an advanced mathematical analyst specializing in crash gaming statistics (e.g., the Aviator casino game).
      
Below is the historical list of the last ${multiplierList.length} crash multipliers from oldest to newest:
[${multiplierList.join(", ")}]

Perform a high-fidelity statistical, psychological, and trend-pattern analysis on this sequence.
Note that the Aviator game uses a certified pseudo-random number generator (PRNG) with independent trials (each round is mathematically independent). However, players suffer from the Gambler's Fallacy and look for patterns.
Your job is to:
1. Summarize the current statistical state of the history (e.g., average, median, ratio of low (<2.0x) vs medium (2.0x-10.0x) vs high (10.0x-20.0x) vs massive (20.0x+) multipliers).
2. Detect common streaks or patterns (e.g., are there consecutive low multipliers, consecutive alternate multipliers, or a long drought of 10x+ or 20x+ multipliers?).
3. Create a forecast for the very next round (predict range, risk level, probability of crashing under 20.0x, probability of going over 20.0x).
4. Provide highly professional, mathematically sound strategy advice (e.g. Martingale limits, Kelly Criterion, or emotional discipline, explicitly cautioning against gambling fallacies).

Provide your complete analysis in valid JSON format matching this exact TypeScript interface:
{
  "summary": "String explaining the current state of the history...",
  "detectedPatterns": ["Pattern 1", "Pattern 2"],
  "nextRoundForecast": {
    "range": "1.0x - 2.0x",
    "probabilityUnder20": 95,
    "probabilityOver20": 5,
    "riskLevel": "MEDIUM"
  },
  "strategyAdvice": "Advice on bankroll management..."
}

Ensure you only return the raw JSON object and nothing else. No markdown wrappers.`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
        }
      });

      const text = response.text;
      if (!text) {
        throw new Error("No response content received from Gemini");
      }

      const prediction = JSON.parse(text);
      res.json(prediction);
    } catch (error: any) {
      console.error("Gemini AI prediction error:", error);
      res.status(500).json({ error: error.message || "Failed to generate AI pattern analysis" });
    }
  });

  // API: Clear history
  app.post("/api/clear", async (req, res) => {
    try {
      const count = localMultipliers.length;
      localMultipliers = [];
      saveLocalMultipliers(localMultipliers);
      res.json({ success: true, count });
    } catch (error: any) {
      console.error("Error clearing multipliers:", error);
      res.status(500).json({ error: error.message || "Failed to clear history" });
    }
  });

  // Serve static UI assets or Vite Dev Middleware
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
